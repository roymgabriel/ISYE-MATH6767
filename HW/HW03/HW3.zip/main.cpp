#include <iostream>
#include "Option.h"
#include "StdNormalCDF.h"
#include "Pricing_Method.h"
#include "Option_Price.h"
#include "Test.h"

using namespace std;
int main() {
    // Define parameters
    double STRIKE, SPOT, RFR, TTM, VOL;
    string flag;
    cout << "Please input Option Parameters" << endl;
    cout << "Strike: ";
    cin >> STRIKE;
    cout << "Spot: ";
    cin >> SPOT;
    cout << "Risk Free Rate: ";
    cin >> RFR;
    cout << "Time to Maturity: ";
    cin >> TTM;
    cout << "Volatility: ";
    cin >> VOL;
    cout << "Put/Call (write one of 'P'/'p' for put or 'C'/'c' for call): ";
    cin >> flag;

    // Calculate Option Price and Delta using the two methods
    pair<double, double> output_BS, output_BP;
//    Option op(STRIKE, SPOT, RFR, TTM, VOL);
    Option_Price OPr(flag, STRIKE, SPOT, RFR, TTM, VOL);
    output_BS = OPr.BSM_Pricer();
    output_BP = OPr.Binomial_Pricer();

    cout << "Option Value using BSM: " << output_BS.first << endl;
    cout << "Option Value using Binomial: " << output_BP.first << endl;

    cout << "Option Delta Value using BSM: " << output_BS.second << endl;
    cout << "Option Delta Value using Binomial: " << output_BP.second << endl;

    cout << "<-------End of Option Pricing------->" << endl;
    cout << "Do you wish to run unit tests? [y/n]?" << endl;
    string ut_flag;
    cin >> ut_flag;

    if (ut_flag=="y" || ut_flag=="Y" || ut_flag == "yes" || ut_flag=="YES" || ut_flag=="Yes") {
        /** Run Unit Tests **/
        cout << "\nRunning Unit Tests...\n\n" << endl;
        // Check Default Option Constructor
        Test ut;
        cout << "Checking Default Option Constructor: " << ut.check_default_option() << endl;

        // Check Manual Input Option
        STRIKE = 100;
        SPOT = 100;
        RFR = 0.1;
        TTM = 0.1;
        VOL = 0.2;
        cout << "Checking Manual Option Input: " << Test::check_option(STRIKE, SPOT, RFR, TTM, VOL) << endl;

        // Check BS Incorrect Inputs
        STRIKE = -100;
        SPOT = 100;
        RFR = 0.1;
        TTM = 0.1;
        VOL = 0.2;
        cout << "Checking Incorrect Strike Input: " << Test::check_incorrect_strike_BS(STRIKE, SPOT, RFR, TTM, VOL)
             << endl;
        STRIKE = 100;
        SPOT = -100;
        RFR = 0.1;
        TTM = 0.1;
        VOL = 0.2;
        cout << "Checking Incorrect Spot Input: " << Test::check_incorrect_spot_BS(STRIKE, SPOT, RFR, TTM, VOL) << endl;
        STRIKE = 100;
        SPOT = 100;
        RFR = -0.1;
        TTM = 0.1;
        VOL = 0.2;
        cout << "Checking Incorrect Rate Input: " << Test::check_incorrect_rate_BS(STRIKE, SPOT, RFR, TTM, VOL) << endl;
        STRIKE = 100;
        SPOT = 100;
        RFR = 0.1;
        TTM = -0.1;
        VOL = 0.2;
        cout << "Checking Incorrect Time Input: " << Test::check_incorrect_time_BS(STRIKE, SPOT, RFR, TTM, VOL) << endl;
        STRIKE = 100;
        SPOT = 100;
        RFR = 0.1;
        TTM = 0.1;
        VOL = -0.2;
        cout << "Checking Incorrect Volatility Input: " << Test::check_incorrect_vol_BS(STRIKE, SPOT, RFR, TTM, VOL)
             << endl;

        // Check BP Incorrect Inputs
        STRIKE = -100;
        SPOT = 100;
        RFR = 0.1;
        TTM = 0.1;
        VOL = 0.2;
        cout << "Checking Incorrect Strike Input: " << Test::check_incorrect_strike_BP(STRIKE, SPOT, RFR, TTM, VOL)
             << endl;
        STRIKE = 100;
        SPOT = -100;
        RFR = 0.1;
        TTM = 0.1;
        VOL = 0.2;
        cout << "Checking Incorrect Spot Input: " << Test::check_incorrect_spot_BP(STRIKE, SPOT, RFR, TTM, VOL) << endl;
        STRIKE = 100;
        SPOT = 100;
        RFR = -0.1;
        TTM = 0.1;
        VOL = 0.2;
        cout << "Checking Incorrect Rate Input: " << Test::check_incorrect_rate_BP(STRIKE, SPOT, RFR, TTM, VOL) << endl;
        STRIKE = 100;
        SPOT = 100;
        RFR = 0.1;
        TTM = -0.1;
        VOL = 0.2;
        cout << "Checking Incorrect Time Input: " << Test::check_incorrect_time_BP(STRIKE, SPOT, RFR, TTM, VOL) << endl;
        STRIKE = 100;
        SPOT = 100;
        RFR = 0.1;
        TTM = 0.1;
        VOL = -0.2;
        cout << "Checking Incorrect Volatility Input: " << Test::check_incorrect_vol_BP(STRIKE, SPOT, RFR, TTM, VOL)
             << endl;
    };

    return 0;
}

