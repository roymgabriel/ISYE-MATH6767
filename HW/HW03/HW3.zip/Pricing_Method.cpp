//
// Created by Roy Makkar Gabriel on 10/2/22.
//

#include "Pricing_Method.h"
