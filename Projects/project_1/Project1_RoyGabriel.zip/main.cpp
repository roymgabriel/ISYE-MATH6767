#include <iostream>
#include "DeltaHedger.h"
#include "DeltaHedgerWithInputData.h"
#include "unit_test.h"

using namespace std;
int main() {
    cout << "Delta Hedging Default Portfolio: " << endl;
    cout << "S = 100, K = 105, T = 0.4, mu = 0.05, vol = 0.24, rf = 0.025, N=100, flag = C" << endl;
    DeltaHedger DH(100, 105, 0.4, 0.05, 0.24, 0.025, 100, "C");
    cout << "Done!\n" << endl;
    cout << "Delta Hedging Using Real Market Data: " << endl;
    cout << "Dates from (07/05/2011-07/29/2011)" << endl;
    DeltaHedgerWithInput DHWI("2011-07-05", "2011-07-29", "2011-09-17", 500);
    cout << "Done!" << endl;

    cout << "Would you like to run unit tests [y/n]?\n" << endl;
    string ut_flag;
    cin >> ut_flag;
    if (ut_flag=="y" || ut_flag=="Y" || ut_flag == "yes" || ut_flag=="YES" || ut_flag=="Yes") {
        cout << "Running Unit Tests..." << endl;
        unit_test ut;
        ut.check_delta();
        ut.check_iv();
    }
    return 0;
}
